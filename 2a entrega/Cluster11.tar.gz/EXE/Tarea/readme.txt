Compilacion:
	javac *.java
Ejecuci�n:
	Pas�ndole un fichero:
		java DriverTarea < input.in
	Por consola:
		java DriverTarea