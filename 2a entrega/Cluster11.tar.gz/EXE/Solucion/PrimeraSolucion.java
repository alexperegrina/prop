

import java.util.ArrayList;

/**
 *
 * @author 
 */
abstract class PrimeraSolucion {
    abstract ArrayList<Integer> obtenerPrimeraSolucion(Grafo G);
}
