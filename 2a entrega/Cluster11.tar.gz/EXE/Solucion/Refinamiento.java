

import java.util.ArrayList;

/**
 *
 * @author 
 */
abstract class Refinamiento {
    abstract ArrayList<Integer> mejorarSolucion(Grafo g, ArrayList<Integer> tour);
}
