import java.util.*;

/**
 *
 * @author Marc Vila Gomez
 */
public abstract class CicloEuleriano {
    public abstract ArrayList<Arista> obtenerCicloEuleriano (Grafo G);
}
