

/**
 *
 * @author David Gracia Celemendi
 */
public abstract class ArbolRecubridorMinimo {
    public abstract Grafo<Integer,Double> obtenerARM(Grafo<Integer,Double> G);
}
