Compilacion:
	javac *.java
Ejecuci�n:
	Pas�ndole un fichero:
		java DriverBranchAndBound < inBranchAndBound.in
	Por consola:
		java DriverBranchAndBound