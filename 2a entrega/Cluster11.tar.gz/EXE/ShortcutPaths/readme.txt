Compilacion:
	javac *.java
Ejecuci�n:
	Pas�ndole un fichero:
		java DriverShortcutPaths < input.in
	Por consola:
		java DriverShortcutPaths