Compilacion:
	javac *.java
Ejecuci�n:
	Pas�ndole un fichero:
		java DriverApareamientoPerfectoMinimo < inDriverApareamiento.in
	Por consola:
		java DriverApareamientoPerfectoMinimo