Compilacion:
	javac *.java
Ejecuci�n:
	Pas�ndole un fichero:
		java DriverKruskal < juegoDePrueba.in
	Por consola:
		java DriverKruskal