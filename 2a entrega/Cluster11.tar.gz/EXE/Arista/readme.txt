Compilacion:
	javac *.java
Ejecuci�n:
	Pas�ndole un fichero:
		java DriverArista < juegoDePrueba.in
	Por consola:
		java DriverArista