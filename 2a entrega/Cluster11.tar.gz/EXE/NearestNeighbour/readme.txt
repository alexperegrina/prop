Compilacion:
	javac *.java
Ejecuci�n:
	Pas�ndole un fichero:
		java DriverNearestNeighbour < input.in
	Por consola:
		java DriverNearestNeighbour