Compilacion:
	javac *.java
Ejecuci�n:
	Pas�ndole un fichero:
		java DriverTresOPT < input.in
	Por consola:
		java DriverTresOPT