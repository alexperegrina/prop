Compilacion:
	javac *.java
Ejecuci�n:
	Pas�ndole un fichero:
		java DriverRelacion < inDriverRelacion.in
	Por consola:
		java DriverRelacion